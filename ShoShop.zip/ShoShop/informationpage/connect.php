<?php
    $con = mysqli_connect("localhost","root","","dtb");
	if(isset($_POST['submit'])){
    $Name = $_POST['name'];
	$Email = $_POST['email'];
	$Phone = $_POST['phone'];
	$NumberOfitem = $_POST['NumberOfItem'];
	$Address = $_POST['address'];
	$sql = mysqli_query($con."INSERT into 'userinformation'('name','email', 'phone', 'NumberOfItem', 'address')
	VALUES('$Name','$Email', '$Phone', '$NumberOfitem', '$Address')")
	or die(mysqli_error($con));
	
	if($sql){
		echo "<script>alert{'done'}</script>";
	}
	else{
		echo "<script>alert{'kosomak'}</script>";
	}
	}
	
?>