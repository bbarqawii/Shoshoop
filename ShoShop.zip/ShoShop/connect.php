<?php
    $name = $_POST['name'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$NumberOfItem = $_POST['NumberOfItem'];
	$address = $_POST['address'];
	
	$conn = new mysqli('localhost','root','','test');
	if($conn->connection_error){
		die('Connection Failed  : '.$conn->connection_error);
	}else{
		$stmt = $conn->prepare("insert into userinformation2(name, email, phone, NumberOfItem, address)
		values(?, ?, ?, ?, ?)");
		$stmt->bind_param("ssiis",$name, $email, $phone, $NumberOfItem, $address);
		$stmt->execute();
		echo "done!!";
		$stmt->close();
		$conn->close();
	}
?>